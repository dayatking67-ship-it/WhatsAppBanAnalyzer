WHATSAPP BAN ANALYZER — PROYEK ANDROID

Isi:
- Aplikasi Android native sederhana dengan WebView.
- Dashboard HTML disimpan lokal di app/src/main/assets/index.html.
- Tidak memeriksa atau mengubah status akun di server WhatsApp.

Cara membuat APK:
1. Ekstrak ZIP.
2. Buka folder WhatsAppBanAnalyzer melalui Android Studio.
3. Tunggu Gradle Sync selesai (Android Studio akan mengunduh komponen build yang diperlukan).
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug tersedia di app/build/outputs/apk/debug/app-debug.apk.

Persyaratan:
- Android Studio versi yang mendukung Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
